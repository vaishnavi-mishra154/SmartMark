const API_URL = "https://2v0by47ng6.execute-api.ap-south-1.amazonaws.com/prod/attendance";

const video = document.getElementById("video");
const result = document.getElementById("result");

// Start camera
navigator.mediaDevices.getUserMedia({ video: true })
.then(stream => {
    video.srcObject = stream;
})
.catch(err => {
    result.innerText = "Camera access denied or not working";
    console.error(err);
});

function capture() {

    result.innerText = "Processing attendance...";

    const studentId = document.getElementById("studentId").value;
    const slot = document.getElementById("slot").value;

    if (!studentId) {

        result.innerText = "Please enter Student ID";
        return;
    }

    const canvas = document.createElement("canvas");

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext("2d");

    ctx.drawImage(video, 0, 0);

    const imageBase64 = canvas.toDataURL("image/jpeg").split(",")[1];

    fetch(API_URL, {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({

            student_id: studentId,
            slot_id: slot,
            image: imageBase64

        })

    })
    .then(response => response.json())

    .then(data => {

        result.innerText = data.message;

    })

    .catch(error => {

        result.innerText = "Error submitting attendance";
        console.error(error);

    });

}